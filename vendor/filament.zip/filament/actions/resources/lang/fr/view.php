<?php

return [

    'single' => [

        'label' => 'Voir',

        'modal' => [

            'heading' => 'Voir :label',

            'actions' => [

                'close' => [
                    'label' => 'Fermer',
                ],

            ],

        ],

    ],

];
