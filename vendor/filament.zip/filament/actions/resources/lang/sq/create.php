<?php

return [

    'single' => [

        'label' => 'Krijo :label',

        'modal' => [

            'heading' => 'Krijo :label',

            'actions' => [

                'create' => [
                    'label' => 'Krijo',
                ],

                'create_another' => [
                    'label' => 'Krijo & krijo një tjetër',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'U krijua',
            ],

        ],

    ],

];
