<?php

return [

    'single' => [

        'label' => 'Ngarko',

        'modal' => [

            'heading' => 'Ngarko :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Ngarko',
                ],

                'attach_another' => [
                    'label' => 'Ngarko & ngarko një tjetër',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'U ngarkua',
            ],

        ],

    ],

];
