<?php

return [

    'single' => [

        'label' => 'Shkëput',

        'modal' => [

            'heading' => 'Shkëput :label',

            'actions' => [

                'detach' => [
                    'label' => 'Shkëput',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'U shkëput',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Shkëput të përzgjedhurin',

        'modal' => [

            'heading' => 'Shkëput të përzgjedhurin :label',

            'actions' => [

                'detach' => [
                    'label' => 'Shkëput',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'U shkëput',
            ],

        ],

    ],

];
