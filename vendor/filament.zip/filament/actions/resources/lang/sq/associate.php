<?php

return [

    'single' => [

        'label' => 'Lidh',

        'modal' => [

            'heading' => 'Lidh :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Regjistro',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Lidh',
                ],

                'associate_another' => [
                    'label' => 'Lidh & lidh another',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'U lidh',
            ],

        ],

    ],

];
