<?php

return [

    'single' => [

        'label' => 'Shkëput',

        'modal' => [

            'heading' => 'Shkëput :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Shkëput',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Shkëput',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Shkëput të përzgjedhurin',

        'modal' => [

            'heading' => 'Shkëput të përzgjedhurin :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Shkëput',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'U shkëput',
            ],

        ],

    ],

];
