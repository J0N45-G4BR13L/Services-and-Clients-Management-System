<?php

return [

    'trigger' => [
        'label' => 'Ações',
    ],

];
