<?php

return [

    'single' => [

        'label' => 'Ջնջել',

        'modal' => [

            'heading' => 'Ջնջել :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ջնջել',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Ջնջվել է',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Ջնջել ընտրվածը',

        'modal' => [

            'heading' => 'Ջնջել ընտրված :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ջնջել',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Ջնջվել է',
            ],

        ],

    ],

];
