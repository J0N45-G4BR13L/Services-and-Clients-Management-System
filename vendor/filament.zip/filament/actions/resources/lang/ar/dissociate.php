<?php

return [

    'single' => [

        'label' => 'فك الارتباط',

        'modal' => [

            'heading' => 'فك ربط :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'فك الارتباط',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'تم فك الارتباط',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'فك ارتباط المحدد',

        'modal' => [

            'heading' => 'فك ارتباط :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'فك ارتباط المحدد',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'تم فك الارتباط',
            ],

        ],

    ],

];
