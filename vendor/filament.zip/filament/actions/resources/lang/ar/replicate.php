<?php

return [

    'single' => [

        'label' => 'نسخة',

        'modal' => [

            'heading' => 'استنساخ :label',

            'actions' => [

                'replicate' => [
                    'label' => 'نسخ',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'تم نسخ السجل',
            ],

        ],

    ],

];
