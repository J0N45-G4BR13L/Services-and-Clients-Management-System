<?php

return [

    'single' => [

        'label' => '解除',

        'modal' => [

            'heading' => ':labelの解除',

            'actions' => [

                'dissociate' => [
                    'label' => '解除',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '解除しました',
            ],

        ],

    ],

    'multiple' => [

        'label' => '選択中を解除',

        'modal' => [

            'heading' => '選択中の:labelを解除',

            'actions' => [

                'dissociate' => [
                    'label' => '解除',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '解除しました',
            ],

        ],

    ],

];
