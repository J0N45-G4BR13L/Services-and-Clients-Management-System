<?php

return [

    'confirmation' => 'Er du sikker på at du vil gjøre dette?',

    'actions' => [

        'cancel' => [
            'label' => 'Avbryt',
        ],

        'confirm' => [
            'label' => 'Bekreft',
        ],

        'submit' => [
            'label' => 'Send',
        ],

    ],

];
