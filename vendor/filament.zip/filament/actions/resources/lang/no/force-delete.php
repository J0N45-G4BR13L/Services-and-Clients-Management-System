<?php

return [

    'single' => [

        'label' => 'Tving sletting',

        'modal' => [

            'heading' => 'Tving sletting av :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slett',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Tving sletting av valgte',

        'modal' => [

            'heading' => 'Tving sletting av valgte :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slett',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

];
