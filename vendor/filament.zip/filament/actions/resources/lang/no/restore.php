<?php

return [

    'single' => [

        'label' => 'Gjenopprett',

        'modal' => [

            'heading' => 'Gjenopprett :label',

            'actions' => [

                'restore' => [
                    'label' => 'Gjenopprett',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Gjenopprettet',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Gjenopprett valgte',

        'modal' => [

            'heading' => 'Gjenopprett valgte :label',

            'actions' => [

                'restore' => [
                    'label' => 'Gjenopprett',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Gjenopprettet',
            ],

        ],

    ],

];
