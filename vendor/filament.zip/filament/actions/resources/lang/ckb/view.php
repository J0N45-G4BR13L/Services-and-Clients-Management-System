<?php

return [

    'single' => [

        'label' => 'بینین',

        'modal' => [

            'heading' => 'بینینی :label',

            'actions' => [

                'close' => [
                    'label' => 'داخستن',
                ],

            ],

        ],

    ],

];
