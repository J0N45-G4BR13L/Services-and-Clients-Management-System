<?php

return [

    'single' => [

        'label' => 'هاوبەشکردن',

        'modal' => [

            'heading' => 'هاوبەشکردنی :label',

            'fields' => [

                'record_id' => [
                    'label' => 'تۆمار',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'هاوبەشکردن',
                ],

                'associate_another' => [
                    'label' => 'هاوبەشکردن و تۆمارێکی تر',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'هاوبەشکراو',
            ],

        ],

    ],

];
