<?php

return [

    'single' => [

        'label' => 'Reproduzir',

        'modal' => [

            'heading' => 'Reproduzir :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Reproduzir',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Reproduzido',
            ],

        ],

    ],

];
