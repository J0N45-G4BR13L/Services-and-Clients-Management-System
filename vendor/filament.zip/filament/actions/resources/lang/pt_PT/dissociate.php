<?php

return [

    'single' => [

        'label' => 'Desassociar',

        'modal' => [

            'heading' => 'Desassociar :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desassociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Desassociado',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Desassociar selecionado',

        'modal' => [

            'heading' => 'Desassociar :label selecionado',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desassociar',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Desassociado',
            ],

        ],

    ],

];
