<?php

return [

    'single' => [

        'label' => 'Criar',

        'modal' => [

            'heading' => 'Criar :label',

            'actions' => [

                'create' => [
                    'label' => 'Criar',
                ],

                'create_another' => [
                    'label' => 'Salvar e criar novo',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Criado!',
            ],

        ],

    ],

];
