<?php

return [

    'single' => [

        'label' => 'Usuń trwale',

        'modal' => [

            'heading' => 'Trwale usuń :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń trwale',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Trwale usunięto',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Trwale usuń zaznaczone',

        'modal' => [

            'heading' => 'Trwale usuń zaznaczone :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń trwale',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Trwale usunięto',
            ],

        ],

    ],

];
