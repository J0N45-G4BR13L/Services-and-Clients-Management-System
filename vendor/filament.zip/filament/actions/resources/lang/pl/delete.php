<?php

return [

    'single' => [

        'label' => 'Usuń',

        'modal' => [

            'heading' => 'Usuń :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Usunięto',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Usuń zaznaczone',

        'modal' => [

            'heading' => 'Usuń zaznaczone :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń zaznaczone',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Usunięto',
            ],

        ],

    ],

];
