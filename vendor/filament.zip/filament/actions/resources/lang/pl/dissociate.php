<?php

return [

    'single' => [

        'label' => 'Usuń powiązanie',

        'modal' => [

            'heading' => 'Usuń powiązanie :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Usuń powiązanie',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Usunięto powiązanie',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Usuń powiązanie zaznaczonych',

        'modal' => [

            'heading' => 'Usuń powiązania zaznaczonych :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Usuń powiązanie zaznaczonych',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Usunięto powiązania',
            ],

        ],

    ],

];
