<?php

return [

    'trigger' => [
        'label' => 'कार्यहरू',
    ],

];
