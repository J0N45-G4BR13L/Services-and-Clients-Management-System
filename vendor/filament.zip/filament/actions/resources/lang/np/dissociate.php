<?php

return [

    'single' => [

        'label' => 'छुटाउनुहोस',

        'modal' => [

            'heading' => ':label लाई छुटाउनुहोस',

            'actions' => [

                'dissociate' => [
                    'label' => 'छुटाउनुहोस',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'छुटाइयो',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'चयन गरिएको छुटाउनुहोस',

        'modal' => [

            'heading' => 'चयन गरिएका :label छुटाउनुहोस ',

            'actions' => [

                'dissociate' => [
                    'label' => 'छुटाउनुहोस',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'छुटाइयो',
            ],

        ],

    ],

];
