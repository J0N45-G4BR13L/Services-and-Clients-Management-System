<?php

return [

    'single' => [

        'label' => 'नयाँ :label',

        'modal' => [

            'heading' => ':label सिर्जना गर्नुहोस्',

            'actions' => [

                'create' => [
                    'label' => 'सिर्जना गर्नुहोस्',
                ],

                'create_another' => [
                    'label' => 'बनाउनुहोस् र अर्को सिर्जना गर्नुहोस्',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'सिर्जना गरियो',
            ],

        ],

    ],

];
