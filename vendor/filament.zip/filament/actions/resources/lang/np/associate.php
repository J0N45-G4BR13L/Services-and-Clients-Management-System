<?php

return [

    'single' => [

        'label' => 'जोड्नुहोस्',

        'modal' => [

            'heading' => ':label सँग जोड्नुहोस्',

            'fields' => [

                'record_id' => [
                    'label' => 'रेकर्ड',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'जोड्नुहोस्',
                ],

                'associate_another' => [
                    'label' => 'यो जोड्नुहोस र अर्को जोड्नुहोस',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'जोडियो',
            ],

        ],

    ],

];
