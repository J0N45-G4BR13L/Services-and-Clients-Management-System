<?php

return [

    'single' => [

        'label' => 'Ștergere',

        'modal' => [

            'heading' => 'Ștergere :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ștergere',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Șters cu succes',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Ștergeți înregistrările selectate',

        'modal' => [

            'heading' => 'Ștergeți :label selectate',

            'actions' => [

                'delete' => [
                    'label' => 'Ștergere',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Șters cu succes',
            ],

        ],

    ],

];
