<?php

return [

    'single' => [

        'label' => 'Vincular',

        'modal' => [

            'heading' => 'Vincular :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registro',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Vincular',
                ],

                'attach_another' => [
                    'label' => 'Vincular y vincular otro',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Vinculados',
            ],

        ],

    ],

];
