<?php

return [

    'single' => [

        'label' => 'Duplikovať',

        'modal' => [

            'heading' => 'Duplikovať :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikovať',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Duplikované',
            ],

        ],

    ],

];
