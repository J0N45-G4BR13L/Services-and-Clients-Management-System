<?php

return [

    'single' => [

        'label' => 'Obnoviť',

        'modal' => [

            'heading' => 'Obnoviť :label',

            'actions' => [

                'restore' => [
                    'label' => 'Obnoviť',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Obnovené',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Obnoviť vybrané',

        'modal' => [

            'heading' => 'Obnoviť vybrané :label',

            'actions' => [

                'restore' => [
                    'label' => 'Obnoviť',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Obnovené',
            ],

        ],

    ],

];
