<?php

return [

    'single' => [

        'label' => 'Upraviť',

        'modal' => [

            'heading' => 'Upraviť :label',

            'actions' => [

                'save' => [
                    'label' => 'Uložiť zmeny',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Uložené',
            ],

        ],

    ],

];
