<?php

return [

    'single' => [

        'label' => 'Trvalo odstrániť',

        'modal' => [

            'heading' => 'Trvalo odstrániť :label',

            'actions' => [

                'delete' => [
                    'label' => 'Odstrániť',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Odstránené',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Trvalo odstrániť vybrané',

        'modal' => [

            'heading' => 'Trvalo odstrániť vybrané :label',

            'actions' => [

                'delete' => [
                    'label' => 'Odstránené',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Odstránené',
            ],

        ],

    ],

];
