<?php

return [

    'single' => [

        'label' => 'Odpojiť',

        'modal' => [

            'heading' => 'Odpojiť :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Odpojiť',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Odpojené',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odpojiť vybrané',

        'modal' => [

            'heading' => 'Odpojiť vybrané :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Odpojiť',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Odpojené',
            ],

        ],

    ],

];
