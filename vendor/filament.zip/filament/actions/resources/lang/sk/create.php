<?php

return [

    'single' => [

        'label' => 'Vytvoriť',

        'modal' => [

            'heading' => 'Vytvoriť :label',

            'actions' => [

                'create' => [
                    'label' => 'Vytvoriť',
                ],

                'create_another' => [
                    'label' => 'Vytvoriť & vytvoriť ďalšie',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Vytvoriť',
            ],

        ],

    ],

];
