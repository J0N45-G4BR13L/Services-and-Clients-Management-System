<?php

return [

    'single' => [

        'label' => 'Zobraziť',

        'modal' => [

            'heading' => 'Zobraziť :label',

            'actions' => [

                'close' => [
                    'label' => 'Zavrieť',
                ],

            ],

        ],

    ],

];
