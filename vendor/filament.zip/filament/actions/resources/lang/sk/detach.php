<?php

return [

    'single' => [

        'label' => 'Odobrať',

        'modal' => [

            'heading' => 'Odobrať :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odobrať',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odobrať',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odobrať vybrané',

        'modal' => [

            'heading' => 'Odobrať vybrané :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odobrať',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odobrať',
            ],

        ],

    ],

];
