<?php

return [

    'trigger' => [
        'label' => 'Akcie',
    ],

];
