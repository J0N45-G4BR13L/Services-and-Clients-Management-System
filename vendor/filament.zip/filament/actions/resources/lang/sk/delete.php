<?php

return [

    'single' => [

        'label' => 'Odstrániť',

        'modal' => [

            'heading' => 'Odstrániť :label',

            'actions' => [

                'delete' => [
                    'label' => 'Odstrániť',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Odstránené',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odstrániť vybrané',

        'modal' => [

            'heading' => 'Odstrániť vybrané :label',

            'actions' => [

                'delete' => [
                    'label' => 'Odstrániť',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Odstránené',
            ],

        ],

    ],

];
