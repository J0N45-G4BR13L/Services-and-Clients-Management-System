<?php

return [

    'single' => [

        'label' => 'Изменить',

        'modal' => [

            'heading' => 'Изменить :label',

            'actions' => [

                'save' => [
                    'label' => 'Сохранить',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Сохранено',
            ],

        ],

    ],

];
