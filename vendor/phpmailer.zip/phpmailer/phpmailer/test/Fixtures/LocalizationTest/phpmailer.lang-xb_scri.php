<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest` to test the fall-back logic.
 */

$PHPMAILER_LANG['empty_message'] = 'XB Lang-script file found';
