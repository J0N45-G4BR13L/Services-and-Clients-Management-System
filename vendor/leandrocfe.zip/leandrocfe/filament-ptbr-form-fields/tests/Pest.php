<?php

use Leandrocfe\FilamentPtbrFormFields\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
