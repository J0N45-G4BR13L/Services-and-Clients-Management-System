<?php

it('can test', function () {
    expect(true)->toBeTrue();
});
