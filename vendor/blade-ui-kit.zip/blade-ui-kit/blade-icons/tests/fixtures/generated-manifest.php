<?php return array (
  'default' =>
  array (
    '{{ dir }}/resources/svg' =>
    array (
      0 => 'camera',
      1 => 'foo-camera',
      2 => 'solid.camera',
      3 => 'xml',
      4 => 'zondicon-flag',
    ),
  ),
  'zondicons' =>
  array (
    '{{ dir }}/resources/zondicons' =>
    array (
      0 => 'flag',
    ),
  ),
);
