# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY.**

## Reporting a Vulnerability

If you discover a security vulnerability within Livewire, please send an email to Caleb Porzio at support@laravel-livewire.com. All security vulnerabilities will be promptly addressed.
