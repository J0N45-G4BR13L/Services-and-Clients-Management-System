Title case: "This Is A Title"
Sentance case: "This is a sentance."
Bullet case: "This is a bullet"
