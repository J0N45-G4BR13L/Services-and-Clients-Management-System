* What to use as a dummy URL: 
    * ? `https://application.test/?page=2`