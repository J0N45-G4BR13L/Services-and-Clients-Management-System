* Start with extracting a Blade component first, then only do a Livewire component if you need to
* 