<?php

namespace Livewire\Features\SupportEntangle;

class UnitTest extends \Tests\TestCase
{
    /** @test */
    public function can_()
    {
        $this->assertTrue(true);
    }
}
