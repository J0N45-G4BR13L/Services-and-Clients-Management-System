
import './wire-transition';
import './wire-wildcard';
import './wire-navigate';
import './wire-confirm';
import './wire-offline'
import './wire-loading';
import './wire-stream';
import './wire-ignore';
import './wire-dirty';
import './wire-model';
import './wire-init';
import './wire-poll';
