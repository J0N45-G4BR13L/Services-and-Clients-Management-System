<div>
    <span dusk="output">On page {{ $page }}</span>
</div>
