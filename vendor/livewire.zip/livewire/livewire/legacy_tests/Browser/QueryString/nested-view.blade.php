<div>
    <span dusk="baz-output">{{ $baz }}</span>

    <input wire:model.live="baz" type="text" dusk="baz-input">
</div>
