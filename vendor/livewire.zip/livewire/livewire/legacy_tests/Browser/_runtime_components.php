<?php

return [
    \LegacyTests\Browser\Events\Component::class,
];