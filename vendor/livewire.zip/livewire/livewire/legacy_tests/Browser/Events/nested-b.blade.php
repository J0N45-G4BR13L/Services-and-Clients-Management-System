<div>
    <span dusk="lastEventForChildB">{{ $this->lastEvent }}</span>
</div>
