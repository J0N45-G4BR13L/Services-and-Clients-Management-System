<div id="nested-root-a">
    <span dusk="lastEventForChildA">{{ $this->lastEvent }}</span>
</div>
