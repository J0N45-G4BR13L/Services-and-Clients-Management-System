<div>
    <button id="click_me" wire:click="clickMe">Click me</button>

    @if($success)
        <h1>Test succeeded</h1>
    @endif
</div>
