<x-layouts.app-for-turbo-views>
    <h1 dusk="page.title">Testing Entangle with Turbo</h1>

    <a dusk="turbo.link" href="{{ $link }}">Go to Livewire Component</a>
</x-layouts.app-for-turbo-views>
