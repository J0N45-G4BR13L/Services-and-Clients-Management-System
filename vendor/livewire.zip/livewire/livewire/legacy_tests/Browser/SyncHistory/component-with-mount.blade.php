<div>
    <span dusk="output">{{ $renamedCompletely }}</span>

    <button wire:click="changeId" dusk="button">Change ID</button>
</div>
