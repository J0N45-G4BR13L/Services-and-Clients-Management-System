<div>
    <input dusk="foo.bar" type="radio" wire:model="foo" value="bar" name="foo">
    <input dusk="foo.baz" type="radio" wire:model="foo" value="baz" name="foo">
</div>
