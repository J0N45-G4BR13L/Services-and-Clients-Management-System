<div>
    <div id="top" style="height: 100vh">
        <div wire:poll.500ms.visible>
            <span dusk="output">{{ $count }}</span>
        </div>
    </div>
    <div id="clearfix">
        No, not really.
    </div>
    <div id="bottom" style="height: 100vh">
        Polling not in view.
    </div>
</div>
