<div>
    {{ get_class($this) }}
</div>
