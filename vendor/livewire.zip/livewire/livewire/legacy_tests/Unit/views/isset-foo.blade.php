<div>
    {{ var_dump(isset($this->foo)) }}
</div>
