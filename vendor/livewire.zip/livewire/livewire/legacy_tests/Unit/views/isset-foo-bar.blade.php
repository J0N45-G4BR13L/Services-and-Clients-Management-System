<div>
    {{ var_dump(isset($this->foo_bar)) }}
</div>
