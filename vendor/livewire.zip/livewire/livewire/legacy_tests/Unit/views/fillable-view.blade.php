<div>
    {{ $publicProperty }}
    {{ $protectedProperty }}
    {{ $privateProperty }}
</div>
