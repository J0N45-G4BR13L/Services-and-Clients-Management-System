<div>
    @livewire('child', $child)
</div>
