<div>
    <?php $callback(); ?>
</div>
