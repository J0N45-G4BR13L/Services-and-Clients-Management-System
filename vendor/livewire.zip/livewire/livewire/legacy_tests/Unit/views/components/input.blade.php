
<div x-data="{ foo: @entangle($attributes->wire('model')) }"></div>
