{{ $bar }}

{{ $slot }}
