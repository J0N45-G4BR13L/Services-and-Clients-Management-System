@yield('content')

{{ $bar }}
