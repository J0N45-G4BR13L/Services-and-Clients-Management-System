@yield('content')

{{ $slot }}{{ $customParam ?? '' }}
