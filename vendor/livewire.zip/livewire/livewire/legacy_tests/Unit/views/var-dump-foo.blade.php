<div>
    {{ var_dump($this->foo) }}
</div>
