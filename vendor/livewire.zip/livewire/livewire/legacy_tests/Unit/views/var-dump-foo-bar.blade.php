<div>
    {{ var_dump($this->foo_bar) }}
</div>
