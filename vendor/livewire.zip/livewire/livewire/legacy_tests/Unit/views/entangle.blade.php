
<x-input wire:model.defer="foo"/>

<x-input wire:model="bar"/>
