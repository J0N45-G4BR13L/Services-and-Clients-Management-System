<div>
    Parent

    @livewire('child', ['number' => 1])
    @livewire('child', ['number' => 2])
</div>
