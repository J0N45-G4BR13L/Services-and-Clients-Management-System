<div>
    @if($downloaded)
        Thanks!
    @endif
</div>
