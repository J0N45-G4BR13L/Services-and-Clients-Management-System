<div>
    @foreach ($models as $model)
        {{ $model->title }}
    @endforeach
</div>
