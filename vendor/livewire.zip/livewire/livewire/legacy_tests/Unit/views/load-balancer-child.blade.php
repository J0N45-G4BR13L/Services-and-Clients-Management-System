<div>
    child-content-{{ $number }}
</div>
