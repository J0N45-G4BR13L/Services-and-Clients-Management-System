<div>
    @if ($model)
        {{ $this->model->title }}
    @endif
</div>
