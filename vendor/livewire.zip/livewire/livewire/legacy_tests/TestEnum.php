<?php

namespace LegacyTests;

enum TestEnum: string
{
    case TEST = 'Be excellent to each other';
}
