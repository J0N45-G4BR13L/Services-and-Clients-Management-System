# Security Policy

If you discover any security related issues, please email lars@flowframe.nl instead of using the issue tracker.
