<?php

use Flowframe\Trend\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
